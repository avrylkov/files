@Library('cs-pipeline-lib@1.0') _

import com.lesfurets.jenkins.unit.global.lib.Library
import com.sbt.processing.pipeline.jenkins.JenkinsNode
import com.sbt.processing.pipeline.JenkinsScript
import com.sbt.processing.pipeline.jenkins.job.Finisher
import com.sbt.processing.pipeline.gradle.Gradle
import com.sbt.processing.pipeline.StageExecutor
import com.sbt.processing.pipeline.Workspace
import com.sbt.processing.pipeline.ose.Openshift

final String OSE_PROJECT = "ci00611271-idevlg-pprbacquiringift"
final String CREDID = "ci00611271-idevlg-pprbacquiringift"
final String BUILD_CONFIG = "src/main/openshift/buildCfg.yml"
final String APP_NAME = "acq-distribution-entity-loader"
final String REPO = "REBEL/" + "distribution-entity-loader"
final String VERSION = "1.0-SNAPSHOT"

timestamps {
    ansiColor('xterm') {
        initialize(this)
        node(JenkinsNode.CI_LINUX_DEFAULT.label()) {
            StageExecutor stageExecutor = new StageExecutor(this)
            Workspace.cleanUp(this)
            def sbtBitbucket = JenkinsScript.jenkins().sbtBitbucket()
            timeout(90) {
                try {
                    sbtBitbucket.checkout(REPO, "master", false)

                    Gradle gradle = new Gradle(this, "5.3.1")
                    gradle.exec("bootJar -Dorg.gradle.daemon=false -Pversion=" + VERSION)

                    stageExecutor.run("Building image") {
                      // set Dockerfile version
                      def dockerFile = readFile("Dockerfile")
                      def newDockerFile = dockerFile.replace('${nexusVersion}', VERSION)
                      writeFile file: "Dockerfile.new", text: newDockerFile
                      sh "rm -f Dockerfile"
                      sh "mv Dockerfile.new Dockerfile"
                      println(dockerFile)
                      //
                      Openshift buildShift = new Openshift(this, Openshift.TEST_SERVER_ID, CREDID, OSE_PROJECT)
                      String result = buildShift.build(BUILD_CONFIG, "Dockerfile", "build/libs/" + APP_NAME + "-" + VERSION + ".jar")
                    }
                } catch (e) {
                    Finisher.onException(this, e)
                    throw e
                }

            }
        }
    }
}