java -Dspring.profiles.active=dev  -jar mapping-app-1.0-SNAPSHOT.jar
