package example.com;

import example.com.mapper.Car;
import example.com.mapper.CarDto;
import example.com.mapper.CarMapper;
import example.com.mapper.Copier;
import example.com.mapper.Person;
import org.junit.Assert;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class MapperTest {

  @Test
  public void testMapping() {

    Car car = new Car();
    car.setMake("Nissan");
    car.setNumberOfSeats(4);
    car.setPrice(30000L);

    Person person = new Person();
    person.setFullName("Alexander");

    car.setPerson(person);

    final CarDto carDto = CarMapper.INSTANCE.carToCarDto(car);

    Assert.assertTrue("Nissan".equals(carDto.getManufacturer()));
    assertThat(carDto.getPersonDto().getName()).isEqualTo("Alexander");
  }


  public void copy(Car src, CarDto dest) {
    dest.setManufacturer(src.getMake());
    dest.setPrice(src.getPrice());
    dest.setSeatCount(src.getNumberOfSeats());
    //....
  }

  @Test
  public void testCopy() {
    Car car = new Car();
    car.setMake("Nissan");
    car.setPrice(10000L);
    car.setNumberOfSeats(4);

    CarDto carDto = new CarDto();
    Copier.copy(car::getMake, carDto::setManufacturer);


    carDto = new CarDto();
    Copier.copy(this::copy, car, carDto);

    Assert.assertTrue("Nissan".equals(carDto.getManufacturer()));

    final boolean compare = Copier.compare((a, b) -> a.getMake().equals(b.getManufacturer())
        && a.getPrice().equals(b.getPrice()), car, carDto);

    Assert.assertTrue(compare);
  }

}
