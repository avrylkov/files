package example.com.mapper;

public class Car {

  private String make;
  private int numberOfSeats;
  private Long price;
  private Person person;


  public String getMake() {
    return make;
  }

  public void setMake(String make) {
    this.make = make;
  }

  public int getNumberOfSeats() {
    return numberOfSeats;
  }

  public void setNumberOfSeats(int numberOfSeats) {
    this.numberOfSeats = numberOfSeats;
  }

  public Long getPrice() {
    return price;
  }

  public void setPrice(Long price) {
    this.price = price;
  }

  public Person getPerson() {
    return person;
  }

  public void setPerson(Person person) {
    this.person = person;
  }
}
