package example.com.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CarMapper {

  public CarMapper INSTANCE = Mappers.getMapper(CarMapper.class);

  @Mapping(source = "make", target = "manufacturer")
  @Mapping(source = "numberOfSeats", target = "seatCount")
  @Mapping(source = "person", target = "personDto")
  public CarDto carToCarDto(Car car);

  @Mapping(source = "fullName", target = "name")
  public PersonDto personToPersonDto2(Person person);

}
