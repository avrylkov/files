package example.com.mapper;

public class CarDto {

  private String manufacturer;
  private Integer seatCount;
  private Long price;
  private PersonDto personDto;

  public String getManufacturer() {
    return manufacturer;
  }

  public void setManufacturer(String manufacturer) {
    this.manufacturer = manufacturer;
  }

  public Integer getSeatCount() {
    return seatCount;
  }

  public void setSeatCount(Integer seatCount) {
    this.seatCount = seatCount;
  }

  public Long getPrice() {
    return price;
  }

  public void setPrice(Long price) {
    this.price = price;
  }

  public PersonDto getPersonDto() {
    return personDto;
  }

  public void setPersonDto(PersonDto personDto) {
    this.personDto = personDto;
  }
}
