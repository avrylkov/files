package example.com.mapper;

import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Copier {

  public static <T> void copy(Supplier<T> source, Consumer<T> destination) {
    destination.accept(source.get());
  }


  public static <T, U> void copy(BiConsumer<T, U> objects, T src, U dest) {
    objects.accept(src, dest);
  }

  public static <T, U> boolean compare(BiPredicate<T, U> objects, T x, U y) {
    return objects.test(x, y);
  }

}
