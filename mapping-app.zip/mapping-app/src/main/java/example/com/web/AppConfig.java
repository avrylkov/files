package example.com.web;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties("app")
@Component
public class AppConfig {

  private String stand;

  public String getStand() {
    return stand;
  }

  public void setStand(String stand) {
    this.stand = stand;
  }

}
