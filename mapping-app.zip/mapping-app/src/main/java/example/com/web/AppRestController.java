package example.com.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppRestController {

  @Autowired
  private Messanger messanger;

  @Autowired
  private AppConfig appConfig;

  @RequestMapping("/")
  public String info() {
    return messanger.getMessage() + ", config stend=" + appConfig.getStand();
  }

}
