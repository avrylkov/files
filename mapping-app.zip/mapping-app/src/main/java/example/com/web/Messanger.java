package example.com.web;

public interface Messanger {

  String getMessage();

}
