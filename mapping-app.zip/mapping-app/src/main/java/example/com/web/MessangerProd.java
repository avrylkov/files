package example.com.web;


import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("prod")
@Component
public class MessangerProd implements Messanger {

  @Override
  public String getMessage() {
    return "Message from Prod";
  }

}
