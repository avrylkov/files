oc apply -f buildConfig.yml

oc new-build --strategy docker --binary --template='bc_template.yml' --name XXXXXX

oc start-build %1 --from-dir . --follow