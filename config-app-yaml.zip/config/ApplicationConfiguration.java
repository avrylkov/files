package com.sbt.acquiring.distributor.loader.config;

import com.sbt.acquiring.distributor.health.StreamStateHealthChecker;
import com.sbt.acquiring.distributor.kafka.admin.TopicCreator;
import java.util.List;
import java.util.Properties;
import org.apache.kafka.streams.StreamsConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;

@Configuration
public class ApplicationConfiguration {
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationConfiguration.class);

    private final StreamsBuilderFactoryBean streamsBuilderFactoryBean;

    @Value("${acq-producer-loader.kafka.topic.input}")
    private String inputTopic;
    @Value("${acq-producer-loader.kafka.topic.output.organization-distribution-request}")
    private String organizationTopic;
    @Value("${acq-producer-loader.kafka.topic.output.subdivision-distribution-request}")
    private String subdivisionTopic;
    @Value("${acq-producer-loader.kafka.topic.output.tracking}")
    private String trackingTopic;

    @Autowired
    public ApplicationConfiguration(StreamsBuilderFactoryBean streamsBuilderFactoryBean) {
        this.streamsBuilderFactoryBean = streamsBuilderFactoryBean;
    }

    @Bean
    public HealthIndicator kStreamHealthIndicator() {
        return new StreamStateHealthChecker(streamsBuilderFactoryBean);
    }

    @Bean
    public ApplicationRunner applicationRunner() {
        return args -> {
            createTopics();
            runStreamProcessing();
        };
    }

    private void runStreamProcessing() {
        streamsBuilderFactoryBean.start();
    }

    private void createTopics() {
        Properties streamsConfiguration = streamsBuilderFactoryBean.getStreamsConfiguration();
        boolean isCreated = TopicCreator.ensureTopicCreated((List<String>) streamsConfiguration.get(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG),
                inputTopic, organizationTopic, subdivisionTopic, trackingTopic);

        if (!isCreated) {
            String errorMsg = "Stop service due to topics are not created";
            LOGGER.error(errorMsg);
            throw new RuntimeException(errorMsg);
        }
    }

}
