package com.sbt.acquiring.distributor.loader.config;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.hibernate5.Hibernate5Module;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.google.common.collect.ImmutableMap;
import com.sbt.acquiring.distributor.kafka.stream.tracking.TrackingConsumerRecordRecoverer;
import com.sbt.acquiring.distributor.kafka.stream.tracking.TrackingStatusHandler;
import com.sbt.acquiring.distributor.loader.serde.DistributionDtoSerde;
import com.sbt.acquiring.distributor.loader.service.LoaderStreamConstructor;
import com.sbt.acquiring.distributor.phase2.dto.input.DistributionDto;
import java.util.Map;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.errors.DefaultProductionExceptionHandler;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.annotation.KafkaStreamsDefaultConfiguration;
import org.springframework.kafka.config.KafkaStreamsConfiguration;
import org.springframework.kafka.listener.ConsumerRecordRecoverer;
import org.springframework.kafka.streams.RecoveringDeserializationExceptionHandler;

@Configuration
@EnableKafka
@EnableKafkaStreams
@EntityScan("com.sbt.acquiring.entities.hibernate.readonly")
public class LoaderStreamConfiguration {
    private final static String STREAM_NAME = "entity-loader";

    @Bean(name = KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    public KafkaStreamsConfiguration kafkaStreamsConfiguration(KafkaProperties kafkaProperties, TrackingStatusHandler trackingStatusHandler) {

        Map<String, Object> config = ImmutableMap.<String, Object>builder()
                .put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getBootstrapServers())
                .put(StreamsConfig.APPLICATION_ID_CONFIG, kafkaProperties.getClientId())
                .put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass())
                .put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, DistributionDtoSerde.class)
                .put(StreamsConfig.DEFAULT_DESERIALIZATION_EXCEPTION_HANDLER_CLASS_CONFIG, RecoveringDeserializationExceptionHandler.class)
                .put(RecoveringDeserializationExceptionHandler.KSTREAM_DESERIALIZATION_RECOVERER, consumerRecordRecoverer(trackingStatusHandler))
                .put(StreamsConfig.DEFAULT_PRODUCTION_EXCEPTION_HANDLER_CLASS_CONFIG, DefaultProductionExceptionHandler.class)
                .build();

        return new KafkaStreamsConfiguration(config);
    }

    @Bean
    public TrackingStatusHandler trackingStatusHandler(KafkaProperties kafkaProperties, @Value("${acq-producer-loader.kafka.topic.output.tracking}") String trackingTopic) {
        return new TrackingStatusHandler(STREAM_NAME, "Entity not found", String.join(",", kafkaProperties.getBootstrapServers()), trackingTopic);
    }

    @Bean
    public KStream<String, DistributionDto> kStream(StreamsBuilder streamsBuilder, LoaderStreamConstructor loaderStreamConstructor) {
        return loaderStreamConstructor.createStream(streamsBuilder);
    }

    @Bean
    public ObjectMapper hibernateCompatibleObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        Hibernate5Module hibernate5Module = new Hibernate5Module();
        hibernate5Module.configure(Hibernate5Module.Feature.FORCE_LAZY_LOADING, true);
        objectMapper.registerModule(hibernate5Module);
        objectMapper.registerModule(new Jdk8Module());
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.NONE);
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper.configure(SerializationFeature.FAIL_ON_SELF_REFERENCES, false);
        return objectMapper;
    }

    /**
     * if any error occur during deserialization, messages will redirect to kafka {in parameter kafkaServers} and topic {in parameter trackingTopic}
     */
    private ConsumerRecordRecoverer consumerRecordRecoverer(TrackingStatusHandler trackingStatusHandler) {
        return new TrackingConsumerRecordRecoverer(STREAM_NAME, trackingStatusHandler);
    }

}
